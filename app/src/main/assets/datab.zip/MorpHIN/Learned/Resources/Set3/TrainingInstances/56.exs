**EXAMPLE FILE**

	verb	conj	adjective	noun	quantifier;
	adjective	noun	noun	demonstrative	adverb;
	pn	cm	noun	cm	quantifier;
