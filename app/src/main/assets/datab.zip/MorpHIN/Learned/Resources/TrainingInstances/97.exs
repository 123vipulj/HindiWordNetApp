**EXAMPLE FILE**

	SYM	*	noun	*	*	cm	*	quantifier;
	demonstrative	*	noun	conj	*	cm	*	quantifier;
	conj	*	cardinal	verb	a51	noun	*	quantifier;
	cm	*	cardinal	pnoun	*	noun	*	quantifier;
	cm	*	cardinal	pnoun	*	adjective	*	quantifier;
	cm	*	quantifier	noun	*	adjective	*	quantifier;
	adverb	*	adjective	verb_aux	*	noun	*	quantifier;
	pn	*	cm	SYM	*	demonstrative	*	pn;
	pn	*	noun	SYM	*	cm	*	quantifier;
	noun	*	noun	conj	*	cm	*	pn;
	cm	*	noun	SYM	*	cm	*	quantifier;
	conj	*	noun	verb	*	noun	*	quantifier;
	cm	*	cm	pn	*	noun	*	pn;
	particle	*	cm	cm	*	noun	*	pn;
	demonstrative	*	noun	SYM	*	adjective	*	quantifier;
	verb_aux	a75	adjective	verb	*	noun	*	quantifier;
