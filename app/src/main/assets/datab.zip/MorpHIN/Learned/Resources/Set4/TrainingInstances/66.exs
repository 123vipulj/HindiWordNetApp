**EXAMPLE FILE**

	nst	verb	pn	particle	conj;
	verb_aux	verb_aux	pn	pnoun	conj;
	noun	verb	nst	cm	conj;
	verb	verb_aux	pnoun	cm	conj;
	verb_aux	SYM	pnoun	conj	conj;
	noun	verb	pn	noun	conj;
