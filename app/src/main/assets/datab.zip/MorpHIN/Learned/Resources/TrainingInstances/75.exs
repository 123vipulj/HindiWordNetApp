**EXAMPLE FILE**

	noun	*	SYM	SYM	*	adverb	*	particle;
