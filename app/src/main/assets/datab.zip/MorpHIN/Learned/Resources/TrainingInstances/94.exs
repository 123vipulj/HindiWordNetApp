**EXAMPLE FILE**

	pn	*	noun	conj	*	cm	*	ordinal;
	cm	*	noun	pnoun	*	cm	*	ordinal;
	pnoun	*	noun	pnoun	*	cm	*	ordinal;
	cm	*	noun	pnoun	*	pnoun	*	ordinal;
	cm	*	pnoun	pnoun	*	noun	*	ordinal;
