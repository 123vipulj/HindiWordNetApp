**EXAMPLE FILE**

	cm	*	noun	noun	a75	cm	*	cardinal;
	cm	*	adjective	pnoun	*	adjective	*	cardinal;
	cm	*	adjective	pnoun	*	noun	*	cardinal;
	cm	*	noun	pnoun	*	cm	*	cardinal;
	pnoun	*	noun	pnoun	*	cm	*	cardinal;
	adjective	*	pnoun	cm	*	cm	*	cardinal;
	cm	*	noun	pnoun	*	cm	*	cardinal;
	noun	*	adjective	conj	*	noun	*	cardinal;
	verb_aux	a75	cardinal	verb	*	noun	*	cardinal;
	cm	*	noun	noun	a84	cm	*	cardinal;
	nst	*	noun	cm	*	particle	*	cardinal;
	cm	*	noun	noun	*	nst	*	cardinal;
	pn	*	cardinal	verb_aux	a75	noun	*	cardinal;
	conj	*	cardinal	verb_aux	a82	noun	*	cardinal;
	conj	*	noun	verb_aux	*	cm	*	cardinal;
	pnoun	*	noun	pnoun	*	pnoun	*	cardinal;
	SYM	*	noun	verb_aux	a75	cm	*	cardinal;
	cm	*	noun	pnoun	*	noun	*	cardinal;
	pn	*	noun	cm	*	cm	*	cardinal;
	cm	*	adjective	cm	*	noun	*	cardinal;
	adverb	*	noun	cm	*	noun	*	cardinal;
	quantifier	*	noun	cm	*	cm	*	cardinal;
	cm	*	noun	pnoun	*	noun	*	cardinal;
	pn	*	pnoun	cm	*	pnoun	*	cardinal;
