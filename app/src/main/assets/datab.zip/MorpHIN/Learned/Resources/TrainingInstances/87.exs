**EXAMPLE FILE**

	noun	*	verb_aux	cardinal	*	verb_aux	a75	verb;
	noun	*	verb_aux	P_wh	*	verb_aux	a75	verb;
	noun	*	verb_aux	quantifier	*	verb_aux	a75	verb;
	cm	*	verb_aux	noun	a23	verb_aux	a75	verb;
	pn	*	verb_aux	cm	*	noun	a75	verb;
	noun	*	verb_aux	cardinal	*	verb_aux	a75	verb;
	noun	*	verb_aux	cardinal	*	verb_aux	a75	verb;
	particle	*	verb_aux	noun	*	verb_aux	a75	verb;
	noun	*	verb_aux	cardinal	*	verb_aux	a75	verb;
	SYM	*	verb_aux	verb_aux	*	noun	a75	verb;
	cm	*	verb_aux	noun	a56	cm	a75	verb;
	noun	*	verb_aux	cardinal	*	verb_aux	a75	verb;
	cm	*	verb_aux	noun	a23	verb_aux	a75	verb;
