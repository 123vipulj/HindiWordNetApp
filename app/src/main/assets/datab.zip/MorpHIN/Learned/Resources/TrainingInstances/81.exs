**EXAMPLE FILE**

	cm	*	cm	noun	*	noun	*	nst;
	cm	*	verb	noun	*	verb_aux	*	nst;
	cm	*	adverb	pnoun	*	verb	*	nst;
	cm	*	verb	noun	a84	adverb	*	nst;
	pn	*	verb	pnoun	*	verb_aux	*	nst;
	cm	*	noun	noun	a75	conj	*	nst;
	cm	*	adverb	noun	*	particle	*	nst;
	cm	*	verb	cardinal	*	cm	*	noun;
	cm	*	noun	noun	a75	verb	*	cm;
	nst	*	cm	cm	*	noun	*	nst;
	pn	*	verb	adverb	*	verb_aux	*	nst;
	P_wh	*	verb	conj	*	verb_aux	*	nst;
	pn	*	cm	noun	*	verb	a75	noun;
	cm	*	cm	noun	*	verb	*	noun;
	SYM	*	verb	*	*	pnoun	*	nst;
	cm	*	verb	noun	*	cm	*	nst;
	noun	a75	verb	adjective	a75	verb_aux	*	nst;
	cm	*	verb	cardinal	*	SYM	*	nst;
	noun	*	verb	cm	*	verb_aux	*	cm;
	cm	*	demonstrative	pnoun	*	noun	*	cm;
	noun	*	verb	cm	*	verb_aux	*	nst;
	cm	*	noun	pnoun	*	cm	*	cm;
	cm	*	verb	noun	a45	cm	*	nst;
