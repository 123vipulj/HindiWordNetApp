**EXAMPLE FILE**

	adjective	*	particle	conj	*	pnoun	*	adverb;
	SYM	*	noun	SYM	*	cm	*	adverb;
	pn	*	particle	conj	*	verb	*	adverb;
	intensifier	*	particle	conj	*	verb	*	adverb;
