**EXAMPLE FILE**

	cm	neg	verb	verb_aux	adjective;
	noun	cm	verb	cardinal	adjective;
	pnoun	cm	noun	verb	adjective;
	conj	pn	adjective	noun	adjective;
