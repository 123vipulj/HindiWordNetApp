**EXAMPLE FILE**

	pn	noun	verb	verb_aux	adverb;
	conj	pn	cm	adjective	inj;
