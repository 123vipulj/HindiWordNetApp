**EXAMPLE FILE**

	noun	cm	conj	particle	adverb;
	noun	cm	particle	verb	pn;
	noun	cm	verb	cm	verb;
