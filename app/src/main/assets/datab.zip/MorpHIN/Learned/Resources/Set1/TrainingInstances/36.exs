**EXAMPLE FILE**

	conj	pnoun	adjective	cm	adjective;
	pnoun	cm	adjective	noun	adjective;
	noun	cm	adjective	noun	cm;
	noun	cm	cardinal	adjective	cm;
