**EXAMPLE FILE**

	noun	cm	cm	nst	pn;
	pnoun	cm	particle	noun	pn;
	pnoun	cm	cm	quantifier	pn;
	verb	conj	noun	cm	pn;
	conj	pnoun	demonstrative	noun	pn;
	noun	cm	noun	verb	pn;
