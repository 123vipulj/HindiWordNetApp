**EXAMPLE FILE**

	verb	*	pn	nst	*	particle	*	conj;
	verb_aux	*	pn	verb_aux	*	pnoun	*	conj;
	verb	*	nst	noun	*	cm	*	conj;
	verb_aux	a75	pnoun	verb	*	cm	*	conj;
	SYM	*	pnoun	*	*	conj	*	conj;
	verb	*	pn	noun	*	noun	*	conj;
	verb_aux	*	adverb	particle	*	pn	*	conj;
	verb_aux	a82	cardinal	verb	a57	cardinal	*	conj;
	SYM	*	adverb	*	*	cm	*	conj;
	SYM	*	adverb	*	*	pnoun	*	conj;
	verb_aux	*	noun	verb	*	quantifier	*	conj;
	verb_aux	*	noun	verb	*	demonstrative	*	conj;
	SYM	*	pnoun	*	*	cm	*	conj;
	SYM	*	noun	*	*	pn	*	conj;
	verb	a57	noun	neg	*	adverb	*	conj;
	verb_aux	*	pn	verb_aux	a32	pn	*	conj;
	verb_aux	*	pnoun	verb	a35	cm	*	conj;
	SYM	*	cardinal	*	*	noun	*	conj;
