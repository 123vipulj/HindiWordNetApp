**EXAMPLE FILE**

	conj	adjective	particle	pnoun	adverb;
	SYM	SYM	noun	cm	adverb;
	conj	pn	particle	verb	adverb;
	conj	intensifier	particle	verb	adverb;
	verb_aux	conj	cm	pn	noun;
