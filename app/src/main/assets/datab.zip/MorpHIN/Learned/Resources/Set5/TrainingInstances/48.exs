**EXAMPLE FILE**

	verb	SYM	pn	demonstrative	inj;
	pnoun	cm	noun	adjective	noun;
	cm	nst	noun	demonstrative	noun;
	pn	particle	cardinal	noun	quantifier;
