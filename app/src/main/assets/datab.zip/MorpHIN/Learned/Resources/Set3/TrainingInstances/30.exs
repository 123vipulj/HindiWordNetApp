**EXAMPLE FILE**

	cm	adjective	cm	pnoun	noun;
	SYM	adjective	cm	noun	noun;
	cm	adjective	cm	verb	noun;
	conj	adjective	cm	noun	adjective;
	pn	adjective	cm	particle	adjective;
	pnoun	adjective	cm	noun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	pnoun	SYM	adjective	noun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	pnoun	SYM	noun	pnoun	adjective;
	pnoun	SYM	noun	pnoun	adjective;
	cm	noun	noun	pnoun	adjective;
	pnoun	cm	noun	conj	adjective;
	noun	cm	noun	noun	adjective;
