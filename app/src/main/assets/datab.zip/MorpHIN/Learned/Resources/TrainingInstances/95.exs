**EXAMPLE FILE**

	pnoun	*	cm	verb	a75	noun	*	pnoun;
	pnoun	*	verb	pn	*	verb_aux	*	pnoun;
	adjective	*	adjective	cardinal	*	noun	a57	particle;
	SYM	*	noun	P_wh	*	noun	a57	particle;
