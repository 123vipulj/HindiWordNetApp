**EXAMPLE FILE**

	verb	noun	verb	verb_aux	pn;
	noun	cm	cm	nst	pn;
	pnoun	cm	particle	noun	pn;
	pnoun	cm	cm	quantifier	pn;
