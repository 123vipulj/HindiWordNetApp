**EXAMPLE FILE**

	verb_aux	pnoun	noun	cm	P_wh;
	noun	noun	adjective	noun	P_wh;
	cm	noun	verb	cm	P_wh;
	verb	conj	nst	verb	P_wh;
	conj	pn	SYM	particle	P_wh;
	demonstrative	noun	noun	cm	P_wh;
