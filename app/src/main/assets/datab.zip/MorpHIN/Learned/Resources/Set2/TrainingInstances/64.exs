**EXAMPLE FILE**

	noun	verb	nst	cm	conj;
	verb	verb_aux	pnoun	cm	conj;
	verb_aux	SYM	pnoun	conj	conj;
	noun	verb	pn	noun	conj;
	particle	verb_aux	pn	pn	conj;
	verb	verb_aux	cardinal	cardinal	conj;
	verb	SYM	pn	particle	conj;
	verb_aux	SYM	pn	pnoun	conj;
	verb	verb_aux	noun	quantifier	conj;
	verb	verb_aux	noun	demonstrative	conj;
	verb_aux	SYM	pnoun	cm	conj;
	verb	SYM	noun	pn	conj;
	neg	verb	noun	adverb	conj;
	verb_aux	verb_aux	pn	pn	conj;
	verb	verb_aux	pnoun	cm	conj;
	verb	SYM	cardinal	noun	conj;
