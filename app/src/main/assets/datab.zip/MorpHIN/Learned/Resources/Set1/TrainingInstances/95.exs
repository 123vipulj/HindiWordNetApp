**EXAMPLE FILE**

	noun	conj	pnoun	pnoun	noun;
	cm	pnoun	cm	verb	pnoun;
