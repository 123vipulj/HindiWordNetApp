**EXAMPLE FILE**

	cm	pn	verb_aux	noun	verb;
	cardinal	noun	verb_aux	verb_aux	verb;
	cardinal	noun	verb_aux	verb_aux	verb;
	noun	particle	verb_aux	verb_aux	verb;
	cardinal	noun	verb_aux	verb_aux	verb;
	verb_aux	SYM	verb_aux	noun	verb;
	noun	cm	verb	cm	verb;
	cardinal	noun	verb_aux	verb_aux	verb;
	noun	cm	verb_aux	verb_aux	verb;
