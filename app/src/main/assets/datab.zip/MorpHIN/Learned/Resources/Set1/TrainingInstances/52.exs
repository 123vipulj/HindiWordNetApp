**EXAMPLE FILE**

	SYM	SYM	noun	cm	adverb;
	conj	pn	particle	verb	adverb;
	conj	intensifier	particle	verb	adverb;
	verb_aux	conj	cm	pn	noun;
	noun	cm	noun	verb	noun;
