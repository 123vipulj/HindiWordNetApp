**EXAMPLE FILE**

	SYM	*	particle	*	*	pnoun	*	cm;
	noun	*	noun	adjective	*	cm	*	cm;
	pnoun	*	noun	conj	*	cm	*	cm;
	verb	a34	adjective	adjective	*	noun	*	cm;
	pnoun	*	adjective	conj	*	noun	*	cm;
	verb	*	pn	pn	*	particle	*	pn;
	adverb	*	pn	SYM	*	noun	*	pn;
	pn	*	noun	adverb	*	pnoun	*	pn;
	pn	*	noun	conj	*	particle	*	cm;
	verb	a34	verb	noun	*	SYM	*	cm;
	verb	a34	verb	noun	*	SYM	*	cm;
