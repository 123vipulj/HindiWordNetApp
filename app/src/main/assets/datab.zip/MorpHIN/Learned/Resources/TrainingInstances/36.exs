**EXAMPLE FILE**

	pn	*	demonstrative	SYM	*	pnoun	*	cm;
	neg	*	conj	noun	a75	adjective	a75	verb;
	SYM	*	SYM	cm	*	noun	*	cm;
