**EXAMPLE FILE**

	verb	a12	noun	cm	*	adjective	*	verb_aux;
	cm	*	noun	noun	*	conj	*	demonstrative;
	cm	*	noun	adverb	*	neg	*	pn;
	cm	*	noun	noun	a23	neg	*	demonstrative;
	nst	*	noun	cm	*	neg	*	demonstrative;
	cm	*	noun	noun	a75	verb	*	demonstrative;
	cm	*	noun	adverb	*	neg	*	demonstrative;
	cm	*	noun	noun	*	neg	*	demonstrative;
	cm	*	noun	noun	a56	neg	*	demonstrative;
	ordinal	*	adjective	pn	*	noun	*	demonstrative;
	SYM	*	particle	SYM	*	noun	*	pn;
	cm	*	noun	noun	a75	verb	*	pn;
	conj	*	neg	verb	*	demonstrative	*	pn;
	neg	*	noun	pn	*	adverb	*	demonstrative;
	noun	*	verb	cm	*	verb_aux	*	demonstrative;
	cm	*	noun	noun	*	verb	*	demonstrative;
	pn	*	noun	pn	*	neg	*	demonstrative;
	cm	*	noun	noun	*	neg	*	demonstrative;
	cm	*	verb	noun	*	verb_aux	*	pn;
	adverb	*	noun	conj	*	neg	*	demonstrative;
	cm	*	noun	verb	*	neg	*	demonstrative;
	cm	*	particle	noun	*	noun	*	demonstrative;
	cm	*	noun	noun	*	noun	*	demonstrative;
	cm	*	noun	noun	*	neg	*	demonstrative;
	cm	*	cardinal	noun	*	pnoun	*	pn;
