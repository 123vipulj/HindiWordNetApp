**EXAMPLE FILE**

	cardinal	*	cm	cm	*	verb	*	noun;
	pnoun	*	noun	cardinal	*	cm	*	noun;
