**EXAMPLE FILE**

	verb_aux	SYM	noun	cm	quantifier;
	conj	demonstrative	noun	cm	quantifier;
	verb	conj	cardinal	noun	quantifier;
	pnoun	cm	cardinal	noun	quantifier;
	pnoun	cm	cardinal	adjective	quantifier;
	noun	cm	quantifier	adjective	quantifier;
	verb	conj	noun	noun	quantifier;
	pn	cm	cm	noun	pn;
	cm	particle	cm	noun	pn;
	SYM	demonstrative	noun	adjective	quantifier;
	verb	verb_aux	adjective	noun	quantifier;
