**EXAMPLE FILE**

	noun	*	verb	noun	*	SYM	*	adjective;
	noun	*	neg	demonstrative	*	verb	*	adjective;
	cm	*	neg	noun	*	verb	*	adjective;
	noun	*	verb	cm	*	cm	*	adjective;
	cm	*	verb	noun	a84	verb_aux	*	adjective;
	noun	a13	verb	verb_aux	a57	verb_aux	*	adjective;
	verb	*	verb	noun	*	SYM	*	adjective;
	verb	*	verb	noun	*	conj	*	adjective;
	noun	*	verb	noun	*	verb_aux	*	adjective;
	particle	*	verb	conj	*	verb_aux	*	adjective;
