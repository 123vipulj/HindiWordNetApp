**EXAMPLE FILE**

	noun	noun	verb	SYM	adjective;
	demonstrative	noun	neg	verb	adjective;
	noun	cm	neg	verb	adjective;
	cm	noun	verb	cm	adjective;
	noun	cm	verb	verb_aux	adjective;
	noun	verb	verb	conj	adjective;
	noun	noun	verb	verb_aux	adjective;
	conj	particle	verb	verb_aux	adjective;
