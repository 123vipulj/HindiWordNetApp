**EXAMPLE FILE**

	noun	noun	adjective	verb	adverb;
	noun	conj	cm	noun	adverb;
	noun	cm	adjective	verb	adverb;
	cardinal	noun	pnoun	cm	adverb;
	cm	noun	verb_aux	SYM	verb;
	cardinal	noun	pn	noun	adverb;
	cm	cm	cm	verb	adverb;
	pnoun	conj	pnoun	cm	adverb;
	adverb	particle	noun	verb	adverb;
	verb_aux	SYM	noun	verb	adverb;
	verb	conj	P_wh	verb	adverb;
	verb_aux	SYM	pn	pn	adverb;
