**EXAMPLE FILE**

	verb	verb_aux	pnoun	pnoun	pn;
	verb	SYM	particle	adjective	pn;
	demonstrative	noun	adjective	verb	pn;
	verb_aux	verb_aux	quantifier	adjective	pn;
	adjective	noun	pnoun	cm	pn;
	verb_aux	verb_aux	noun	pn	pn;
	noun	verb	pnoun	conj	pn;
	SYM	noun	pnoun	pnoun	pn;
	SYM	conj	pnoun	noun	pn;
	verb	conj	pn	cm	pn;
	verb	verb_aux	noun	verb	pn;
	pn	noun	noun	cm	pn;
	particle	conj	pn	demonstrative	pn;
	verb	conj	cm	demonstrative	pn;
	SYM	pn	noun	cm	pn;
	SYM	adjective	pnoun	verb	pn;
	particle	verb	cardinal	noun	conj;
	verb_aux	conj	pnoun	noun	pn;
	verb	conj	pn	noun	pn;
	noun	verb	pn	noun	pn;
	verb_aux	verb_aux	pnoun	cm	pn;
	SYM	SYM	noun	cm	pn;
	verb_aux	verb_aux	noun	cm	pn;
