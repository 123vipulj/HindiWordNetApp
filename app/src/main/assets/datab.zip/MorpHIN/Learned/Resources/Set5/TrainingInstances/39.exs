**EXAMPLE FILE**

	noun	cm	verb_aux	verb	verb;
