**EXAMPLE FILE**

	SYM	*	pn	*	*	demonstrative	*	inj;
	cm	*	noun	pnoun	*	adjective	*	noun;
	nst	*	noun	cm	*	demonstrative	*	noun;
	particle	*	cardinal	pn	*	noun	*	quantifier;
	pnoun	*	noun	SYM	*	cm	*	noun;
