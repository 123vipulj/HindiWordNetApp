**EXAMPLE FILE**

	conj	pn	cm	adjective	inj;
