**EXAMPLE FILE**

	SYM	SYM	noun	cardinal	adjective;
