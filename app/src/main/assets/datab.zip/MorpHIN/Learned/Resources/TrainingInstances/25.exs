**EXAMPLE FILE**

	cm	*	noun	noun	*	verb	*	P_wh;
