**EXAMPLE FILE**

	noun	a51	verb	verb	*	verb_aux	*	pn;
	cm	*	cm	noun	*	nst	*	pn;
	cm	*	particle	pnoun	*	noun	*	pn;
	cm	*	cm	pnoun	*	quantifier	*	pn;
	conj	*	noun	verb	*	cm	*	pn;
	pnoun	*	demonstrative	conj	*	noun	*	pn;
	cm	*	noun	noun	*	verb	*	pn;
