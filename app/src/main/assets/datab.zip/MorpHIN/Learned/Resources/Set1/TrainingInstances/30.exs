**EXAMPLE FILE**

	pnoun	adjective	cm	noun	adjective;
	conj	cardinal	pnoun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	cm	adjective	noun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	pnoun	SYM	adjective	noun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	pnoun	SYM	noun	pnoun	adjective;
	pnoun	SYM	noun	pnoun	adjective;
	cm	noun	noun	pnoun	adjective;
	pnoun	cm	noun	conj	adjective;
	noun	cm	noun	noun	adjective;
