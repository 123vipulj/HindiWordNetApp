**EXAMPLE FILE**

	noun	cardinal	cm	particle	cardinal;
	adjective	cardinal	cardinal	verb	cardinal;
	noun	cm	noun	noun	cardinal;
	cm	cardinal	noun	cm	cardinal;
	verb	conj	noun	noun	cardinal;
	noun	cm	noun	cm	cardinal;
	cm	cardinal	cm	quantifier	noun;
	cm	cardinal	particle	quantifier	cardinal;
	pnoun	cm	cm	noun	noun;
	verb	particle	pnoun	noun	cardinal;
	verb	cardinal	cm	quantifier	noun;
	SYM	cardinal	cm	verb	noun;
	pn	cardinal	cm	particle	cardinal;
	verb_aux	SYM	noun	nst	cardinal;
	pn	cardinal	noun	particle	cardinal;
	cm	cardinal	cm	quantifier	cardinal;
	pn	cardinal	noun	verb	cardinal;
	cm	nst	pnoun	SYM	cardinal;
	demonstrative	noun	pnoun	cm	cardinal;
	cm	cm	noun	nst	cardinal;
	pn	cm	noun	adjective	cardinal;
	adverb	cardinal	noun	cm	noun;
	cm	cardinal	cardinal	cm	noun;
	pn	cm	cm	nst	noun;
	cm	cardinal	noun	cm	cardinal;
	particle	quantifier	noun	verb	cardinal;
