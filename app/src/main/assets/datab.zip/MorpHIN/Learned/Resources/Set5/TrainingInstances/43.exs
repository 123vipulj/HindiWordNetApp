**EXAMPLE FILE**

	noun	cm	noun	demonstrative	quantifier;
	noun	cm	verb	cm	quantifier;
	verb_aux	noun	neg	verb	quantifier;
	pnoun	cm	neg	verb	quantifier;
	cm	cm	adjective	noun	quantifier;
	cm	nst	noun	cm	quantifier;
	noun	noun	verb	cm	adjective;
	noun	conj	noun	particle	quantifier;
	cardinal	noun	verb	cm	quantifier;
	verb_aux	pn	verb	verb_aux	adjective;
