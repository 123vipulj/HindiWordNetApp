**EXAMPLE FILE**

	cm	nst	noun	noun	cm;
	adverb	conj	noun	adjective	cm;
	demonstrative	noun	noun	noun	neg;
