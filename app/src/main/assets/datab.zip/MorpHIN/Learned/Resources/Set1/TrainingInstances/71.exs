**EXAMPLE FILE**

	verb_aux	SYM	pnoun	adjective	conj;
