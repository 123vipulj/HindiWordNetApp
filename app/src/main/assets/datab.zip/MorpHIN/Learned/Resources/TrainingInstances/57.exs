**EXAMPLE FILE**

	cm	*	noun	noun	*	pnoun	*	P_wh;
	cm	*	verb	noun	*	verb_aux	*	P_wh;
	noun	*	verb	pn	*	SYM	*	P_wh;
	adjective	*	verb	cm	*	verb_aux	*	P_wh;
