**EXAMPLE FILE**

	noun	*	cm	cm	*	adjective	a75	adjective;
	SYM	*	particle	verb	*	adjective	a75	adjective;
	verb_aux	a75	particle	verb	a12	pn	*	conj;
