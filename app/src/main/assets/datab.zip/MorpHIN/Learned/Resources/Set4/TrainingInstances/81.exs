**EXAMPLE FILE**

	pnoun	cm	cm	noun	nst;
	noun	cm	verb	verb_aux	nst;
	pnoun	cm	pn	verb	nst;
	noun	cm	verb	pn	cm;
	pnoun	pn	verb	verb_aux	nst;
	noun	cm	noun	conj	nst;
	noun	cm	pn	particle	nst;
	noun	cm	noun	verb	cm;
	cm	nst	cm	noun	nst;
	adjective	noun	verb	verb_aux	nst;
	cardinal	cm	verb	SYM	nst;
	cm	noun	verb	verb_aux	cm;
	pnoun	cm	demonstrative	noun	cm;
	cm	noun	verb	verb_aux	cm;
	pnoun	cm	noun	cm	cm;
	noun	cm	verb	cm	nst;
