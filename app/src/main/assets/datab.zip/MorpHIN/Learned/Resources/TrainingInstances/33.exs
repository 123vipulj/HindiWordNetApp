**EXAMPLE FILE**

	cm	*	noun	pnoun	*	pnoun	*	adjective;
	pn	*	noun	particle	*	pnoun	*	adjective;
