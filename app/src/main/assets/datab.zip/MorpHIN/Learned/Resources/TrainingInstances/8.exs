**EXAMPLE FILE**

	cm	adjective	cm	pnoun	noun;
	SYM	adjective	cm	noun	noun;
	cm	adjective	cm	verb	noun;
	conj	adjective	cm	noun	adjective;
	pn	adjective	cm	particle	adjective;
	pnoun	adjective	cm	noun	adjective;
	conj	cardinal	pnoun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	cm	adjective	noun	pnoun	adjective;
	noun	cm	noun	pnoun	adjective;
	pnoun	cm	noun	pnoun	adjective;
	pnoun	cm	noun	pnoun	adjective;
