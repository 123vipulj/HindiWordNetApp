**EXAMPLE FILE**

	verb_aux	SYM	nst	noun	adverb;
	verb_aux	SYM	demonstrative	noun	adverb;
	pnoun	verb	demonstrative	noun	pn;
	verb_aux	verb_aux	pn	noun	pn;
	cm	verb	adjective	noun	pn;
	verb	verb_aux	adjective	pnoun	pn;
	noun	verb	demonstrative	noun	pn;
	pn	pn	verb	noun	pn;
	pnoun	cm	quantifier	noun	pn;
	noun	verb	demonstrative	noun	pn;
	verb_aux	SYM	pn	cardinal	pn;
	verb	verb_aux	adjective	noun	pn;
