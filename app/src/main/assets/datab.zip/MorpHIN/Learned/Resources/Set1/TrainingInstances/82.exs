**EXAMPLE FILE**

	cm	cardinal	cm	adjective	pnoun;
	noun	cardinal	cm	pnoun	pnoun;
	noun	cardinal	cm	pnoun	pnoun;
