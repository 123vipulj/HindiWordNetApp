**EXAMPLE FILE**

	SYM	pn	SYM	noun	adjective;
	pn	pn	noun	verb	adjective;
