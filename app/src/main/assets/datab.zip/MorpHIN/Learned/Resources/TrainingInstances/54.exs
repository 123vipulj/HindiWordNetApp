**EXAMPLE FILE**

	cm	*	pnoun	noun	*	cm	*	cm;
	cm	*	noun	noun	*	verb	*	cm;
