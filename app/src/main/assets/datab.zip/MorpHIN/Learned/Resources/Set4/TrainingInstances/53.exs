**EXAMPLE FILE**

	conj	adjective	particle	pnoun	adverb;
	SYM	SYM	noun	cm	adverb;
	conj	pn	particle	verb	adverb;
	noun	cm	noun	verb	noun;
