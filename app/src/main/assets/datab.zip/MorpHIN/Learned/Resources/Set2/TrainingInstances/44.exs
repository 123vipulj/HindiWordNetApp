**EXAMPLE FILE**

	noun	noun	adjective	verb	adverb;
	noun	conj	cm	noun	adverb;
	cardinal	noun	pn	noun	adverb;
	cm	cm	cm	verb	adverb;
	pnoun	conj	pnoun	cm	adverb;
	adverb	particle	noun	verb	adverb;
	verb_aux	SYM	noun	verb	adverb;
	verb	conj	P_wh	verb	adverb;
	verb_aux	SYM	pn	pn	adverb;
	verb	noun	particle	noun	adverb;
	demonstrative	noun	noun	cm	adverb;
	verb_aux	conj	pn	noun	adverb;
	SYM	pn	demonstrative	noun	adverb;
