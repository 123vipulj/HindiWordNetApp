**EXAMPLE FILE**

	pn	noun	verb	verb_aux	adverb;
