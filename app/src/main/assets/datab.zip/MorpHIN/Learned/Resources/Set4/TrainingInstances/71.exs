**EXAMPLE FILE**

	quantifier	adjective	verb_aux	verb_aux	verb;
