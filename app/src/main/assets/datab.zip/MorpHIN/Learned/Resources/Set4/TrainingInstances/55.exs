**EXAMPLE FILE**

	noun	cm	pnoun	cm	cm;
