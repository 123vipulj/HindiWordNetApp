**EXAMPLE FILE**

	cm	cm	noun	verb	P_wh;
	cm	conj	pn	demonstrative	P_wh;
	conj	pn	noun	verb	P_wh;
	noun	noun	pnoun	cm	P_wh;
	cm	noun	verb	SYM	P_wh;
