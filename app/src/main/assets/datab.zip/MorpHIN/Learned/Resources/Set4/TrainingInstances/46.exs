**EXAMPLE FILE**

	noun	noun	adjective	verb	adverb;
	noun	conj	cm	noun	adverb;
	noun	cm	adjective	verb	adverb;
	cardinal	noun	pnoun	cm	adverb;
	cm	noun	verb_aux	SYM	verb;
	cardinal	noun	pn	noun	adverb;
	cm	cm	cm	verb	adverb;
	verb	noun	particle	noun	adverb;
	demonstrative	noun	noun	cm	adverb;
	verb_aux	conj	pn	noun	adverb;
	SYM	pn	demonstrative	noun	adverb;
