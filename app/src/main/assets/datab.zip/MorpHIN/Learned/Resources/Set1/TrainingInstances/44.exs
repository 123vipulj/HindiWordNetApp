**EXAMPLE FILE**

	verb_aux	cm	verb	verb_aux	adjective;
	adjective	pnoun	verb_aux	cm	verb;
	noun	cm	verb_aux	conj	verb;
	noun	cm	verb_aux	conj	verb;
	pnoun	cm	noun	cm	verb;
	conj	noun	verb_aux	cm	verb;
	pnoun	cm	noun	SYM	adjective;
	adverb	particle	verb_aux	verb_aux	verb;
	conj	noun	verb_aux	verb_aux	verb;
	particle	nst	verb_aux	verb_aux	verb;
	cm	quantifier	noun	verb	adjective;
	adjective	noun	verb_aux	verb_aux	verb;
	noun	demonstrative	verb_aux	noun	verb;
	noun	cm	SYM	noun	verb;
	demonstrative	noun	verb_aux	verb_aux	verb;
	quantifier	particle	adjective	noun	adjective;
	particle	adjective	noun	cm	adjective;
	pn	neg	pn	noun	verb;
	noun	cm	verb_aux	verb_aux	verb;
	verb_aux	pn	neg	verb	adjective;
	cm	noun	verb_aux	conj	verb;
	noun	cm	noun	verb	adjective;
	verb	cm	verb_aux	verb_aux	verb;
	adjective	P_wh	verb_aux	verb_aux	verb;
	demonstrative	noun	pn	noun	verb;
	cm	noun	verb_aux	conj	verb;
