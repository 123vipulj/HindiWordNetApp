**EXAMPLE FILE**

	cm	noun	noun	cm	quantifier;
	verb	cm	noun	verb	quantifier;
	verb	conj	pnoun	noun	quantifier;
	verb_aux	conj	noun	cm	quantifier;
	verb	pn	noun	cm	quantifier;
	adjective	noun	verb	verb_aux	quantifier;
	SYM	cardinal	noun	SYM	quantifier;
	verb	SYM	noun	adjective	quantifier;
	cardinal	cm	noun	noun	quantifier;
	particle	noun	noun	cm	quantifier;
	verb	cm	noun	cm	adjective;
	noun	cm	noun	verb	adjective;
	noun	cm	noun	noun	quantifier;
