**EXAMPLE FILE**

	neg	*	verb	cm	*	verb_aux	*	adjective;
	quantifier	*	cm	pn	*	adjective	*	adjective;
	cm	*	verb	noun	*	cardinal	*	adjective;
	cm	*	noun	pnoun	*	verb	*	adjective;
	pn	*	adjective	conj	*	noun	*	adjective;
