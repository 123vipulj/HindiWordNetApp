**EXAMPLE FILE**

	cm	pn	verb	pnoun	quantifier;
	cm	pn	noun	adjective	quantifier;
	cm	particle	pnoun	noun	quantifier;
	noun	cm	particle	quantifier	quantifier;
	quantifier	particle	adverb	noun	quantifier;
	cardinal	cm	noun	cm	quantifier;
	noun	cm	noun	cm	quantifier;
	cm	particle	noun	SYM	quantifier;
	pn	intensifier	noun	verb	quantifier;
	cm	pn	noun	adjective	quantifier;
