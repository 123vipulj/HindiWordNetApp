**EXAMPLE FILE**

	SYM	*	noun	SYM	*	cardinal	*	adjective;
	cardinal	*	noun	cm	*	cm	*	adjective;
