**EXAMPLE FILE**

	verb	verb_aux	adjective	noun	pn;
	verb	verb_aux	demonstrative	noun	pn;
	pnoun	cm	noun	cm	pn;
	verb	verb_aux	demonstrative	quantifier	pn;
	pnoun	cm	cm	adjective	pn;
	noun	verb	pnoun	pnoun	pn;
	verb_aux	verb_aux	demonstrative	pnoun	pn;
	pn	adverb	verb	pn	adverb;
	adverb	verb	quantifier	noun	pn;
	verb	verb_aux	pnoun	pnoun	pn;
	verb	SYM	particle	adjective	pn;
	demonstrative	noun	adjective	verb	pn;
	verb_aux	verb_aux	quantifier	adjective	pn;
	adjective	noun	pnoun	cm	pn;
	verb_aux	verb_aux	noun	pn	pn;
	noun	verb	pnoun	conj	pn;
	verb	conj	pn	noun	pn;
	noun	verb	pn	noun	pn;
	verb_aux	verb_aux	pnoun	cm	pn;
	SYM	SYM	noun	cm	pn;
	verb_aux	verb_aux	noun	cm	pn;
