**EXAMPLE FILE**

	noun	noun	verb	SYM	adjective;
	demonstrative	noun	neg	verb	adjective;
	noun	cm	neg	verb	adjective;
	cm	noun	verb	cm	adjective;
	adjective	noun	verb	verb_aux	adjective;
	cm	noun	verb	cm	adjective;
	noun	verb	verb	SYM	adjective;
	cardinal	noun	verb	verb_aux	adjective;
	nst	particle	verb	verb_aux	adjective;
	noun	verb	verb	conj	adjective;
	noun	noun	verb	verb_aux	adjective;
	conj	particle	verb	verb_aux	adjective;
