**EXAMPLE FILE**

	cm	verb	noun	adjective	verb_aux;
	noun	cm	noun	conj	demonstrative;
	adverb	particle	noun	neg	pn;
	noun	cm	noun	neg	demonstrative;
	cm	nst	noun	neg	demonstrative;
	noun	cm	noun	verb	demonstrative;
	nst	particle	noun	neg	demonstrative;
	noun	cm	noun	neg	demonstrative;
	noun	cm	noun	neg	demonstrative;
	pn	ordinal	adjective	noun	demonstrative;
	SYM	SYM	particle	noun	pn;
	noun	cm	noun	verb	pn;
	conj	pn	noun	neg	demonstrative;
	verb	cm	noun	neg	demonstrative;
	noun	cm	particle	noun	demonstrative;
	noun	cm	noun	noun	demonstrative;
	noun	cm	noun	neg	demonstrative;
	noun	cm	cardinal	pnoun	pn;
