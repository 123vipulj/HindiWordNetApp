**EXAMPLE FILE**

	noun	cm	conj	particle	adverb;
	noun	cm	verb	cm	verb;
