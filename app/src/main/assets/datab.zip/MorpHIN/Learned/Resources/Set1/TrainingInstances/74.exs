**EXAMPLE FILE**

	conj	pnoun	noun	cm	cm;
	adjective	verb	adjective	noun	cm;
	conj	pnoun	adjective	noun	cm;
	pn	verb	pn	particle	pn;
	SYM	adverb	pn	noun	pn;
	adverb	pn	noun	pnoun	pn;
	conj	pn	noun	particle	cm;
	noun	verb	verb	SYM	cm;
	noun	verb	verb	SYM	cm;
