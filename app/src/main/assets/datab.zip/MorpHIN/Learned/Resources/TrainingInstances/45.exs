**EXAMPLE FILE**

	noun	a76	adjective	noun	*	verb	*	adverb;
	conj	*	cm	noun	*	noun	*	adverb;
	cm	*	adjective	noun	*	verb	*	adverb;
	noun	*	pnoun	cardinal	*	cm	*	adverb;
	noun	a33	verb_aux	cm	*	SYM	*	verb;
	noun	*	pn	cardinal	*	noun	*	adverb;
	cm	*	cm	cm	*	verb	*	adverb;
	conj	*	pnoun	pnoun	*	cm	*	adverb;
	particle	*	noun	adverb	*	verb	*	adverb;
	SYM	*	noun	*	*	verb	*	adverb;
	conj	*	P_wh	verb	a28	verb	*	adverb;
	SYM	*	pn	*	*	pn	*	adverb;
	noun	*	cm	verb	a31	noun	*	adverb;
	noun	*	noun	demonstrative	*	cm	*	adverb;
	conj	*	pn	verb_aux	*	noun	*	adverb;
	pn	*	demonstrative	SYM	*	noun	*	adverb;
