**EXAMPLE FILE**

	adjective	*	cm	cm	*	pnoun	*	noun;
	adjective	*	cm	SYM	*	noun	*	noun;
	adjective	*	cm	cm	*	verb	*	noun;
	adjective	*	cm	conj	*	noun	*	adjective;
	adjective	*	cm	pn	*	particle	*	adjective;
	adjective	*	cm	pnoun	*	noun	*	adjective;
	cardinal	*	pnoun	conj	*	pnoun	*	adjective;
	cm	*	noun	noun	*	pnoun	*	adjective;
	adjective	*	noun	cm	*	pnoun	*	adjective;
	cm	*	noun	noun	*	pnoun	*	adjective;
	cm	*	noun	pnoun	*	pnoun	*	adjective;
	cm	*	noun	pnoun	*	pnoun	*	adjective;
	SYM	*	adjective	pnoun	*	noun	*	adjective;
	cm	*	noun	pnoun	*	pnoun	*	adjective;
	cm	*	noun	noun	*	pnoun	*	adjective;
	SYM	*	noun	pnoun	*	pnoun	*	adjective;
	SYM	*	noun	pnoun	a51	pnoun	*	adjective;
	noun	*	noun	cm	*	pnoun	*	adjective;
	cm	*	noun	pnoun	*	conj	*	adjective;
	cm	*	noun	noun	*	noun	*	adjective;
