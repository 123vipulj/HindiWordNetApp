**EXAMPLE FILE**

	noun	cm	noun	verb	cm;
