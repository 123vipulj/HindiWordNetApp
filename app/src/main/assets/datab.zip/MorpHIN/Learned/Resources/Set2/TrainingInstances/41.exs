**EXAMPLE FILE**

	noun	cm	noun	demonstrative	quantifier;
	noun	cm	verb	cm	quantifier;
	verb_aux	noun	neg	verb	quantifier;
	pnoun	cm	neg	verb	quantifier;
	cardinal	noun	verb	cm	quantifier;
	verb_aux	pn	verb	verb_aux	adjective;
	cm	demonstrative	noun	cm	quantifier;
	pn	verb	noun	cm	quantifier;
	pn	particle	noun	cm	quantifier;
