**EXAMPLE FILE**

	cm	cm	noun	quantifier	pn;
	pnoun	cm	ordinal	pnoun	pn;
	cm	noun	noun	P_wh	pn;
	noun	cm	noun	verb	pn;
	particle	cm	pn	adjective	pn;
	noun	cm	verb_aux	verb_aux	verb;
	pnoun	cm	adjective	noun	pn;
	cm	nst	noun	adjective	pn;
	cm	noun	quantifier	noun	pn;
